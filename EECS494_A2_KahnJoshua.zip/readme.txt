Note:

If the game boots up and the collisions are acting weird, please try restarting the executable.
(This was a last minute problem I didn't have time to look at).