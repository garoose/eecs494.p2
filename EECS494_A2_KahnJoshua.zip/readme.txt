Note:

If the game boots up and the collisions are acting weird, please try restarting the executable.